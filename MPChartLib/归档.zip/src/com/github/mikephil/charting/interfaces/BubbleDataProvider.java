package com.github.mikephil.charting.interfaces;

import com.github.mikephil.charting.data.BubbleData;

public interface BubbleDataProvider extends BarLineScatterCandleBubbleDataProvider {

    public BubbleData getBubbleData();
}
